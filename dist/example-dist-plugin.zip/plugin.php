<?php
/**
 * Plugin Name: Example Dist Plugin
 * Plugin URI:  http://example.com
 * Description: A shining example.
 * Version:     1.2.11
 * Author:      Eric Teubert
 * Author URI:  http://example.com
 * License:     MIT
 * Text Domain: example-dist-plugin
 * GitHub Plugin URI: https://github.com/eteubert/example-dist-plugin
 * Release Asset: true
 */

// a change
